CS 61 Problem Set 2
===================

This is bomb #56.

It belongs to johnsmith (cfzimmerman@college.harvard.edu).
